#!/bin/bash
# Cria serviço systemd para o C2 Admin System

if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Execute como root (sudo)"
    exit 1
fi

# Carregar variáveis de ambiente
if [ ! -f .env ]; then
    echo "⚠️  Arquivo .env não encontrado! Execute install.sh primeiro."
    exit 1
fi

source .env

# Obter diretório atual
CURRENT_DIR=$(pwd)

# Criar arquivo de serviço
cat > /etc/systemd/system/c2-admin.service << EOF
[Unit]
Description=C2 Admin System
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$CURRENT_DIR
Environment="C2_SECRET_TOKEN=$C2_SECRET_TOKEN"
Environment="C2_ADMIN_PASSWORD=$C2_ADMIN_PASSWORD"
ExecStart=/usr/bin/python3 $CURRENT_DIR/app.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Recarregar systemd
systemctl daemon-reload

# Habilitar e iniciar serviço
systemctl enable c2-admin
systemctl start c2-admin

echo "✅ Serviço criado e iniciado!"
echo ""
echo "Comandos úteis:"
echo "  systemctl status c2-admin   # Ver status"
echo "  systemctl stop c2-admin     # Parar"
echo "  systemctl start c2-admin    # Iniciar"
echo "  systemctl restart c2-admin  # Reiniciar"
echo "  journalctl -u c2-admin -f   # Ver logs"

