#!/bin/bash
# Script de instalação automática do C2 Admin System

echo "============================================================"
echo "🚀 C2 Admin System - Instalação Automática"
echo "============================================================"
echo ""

# Verificar se está rodando como root
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Por favor, execute como root (sudo)"
    exit 1
fi

# Atualizar sistema
echo "📦 Atualizando sistema..."
apt update && apt upgrade -y

# Instalar Python e pip
echo "🐍 Instalando Python 3..."
apt install python3 python3-pip curl -y

# Instalar dependências Python
echo "📚 Instalando dependências..."
pip3 install -r requirements.txt

# Gerar credenciais
echo ""
echo "🔐 Gerando credenciais de segurança..."
SECRET_TOKEN=$(python3 -c "import secrets; print(secrets.token_hex(32))")
ADMIN_PASSWORD=$(python3 -c "import secrets; print(secrets.token_urlsafe(16))")

# Salvar em arquivo .env
cat > .env << EOF
C2_SECRET_TOKEN=$SECRET_TOKEN
C2_ADMIN_PASSWORD=$ADMIN_PASSWORD
EOF

echo ""
echo "============================================================"
echo "✅ Instalação Concluída!"
echo "============================================================"
echo ""
echo "📡 Secret Token: $SECRET_TOKEN"
echo "🔑 Admin Password: $ADMIN_PASSWORD"
echo ""
echo "⚠️  IMPORTANTE: Anote essas credenciais!"
echo "⚠️  Elas foram salvas em .env"
echo ""
echo "Para iniciar o servidor:"
echo "  source .env"
echo "  python3 app.py"
echo ""
echo "Para criar serviço systemd:"
echo "  ./create_service.sh"
echo ""
echo "============================================================"

